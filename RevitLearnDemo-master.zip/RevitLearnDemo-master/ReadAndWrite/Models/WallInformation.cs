﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadAndWrite
{
    public class WallInformation
    {

        //墙ID
        public int WallId { get; set; }

        //算出来的
        //面积
        public double Area { get; set; }
        //长度
        public double Length { get; set; }


    }
}
